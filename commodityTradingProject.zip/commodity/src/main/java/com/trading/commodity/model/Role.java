package com.trading.commodity.model;

public enum Role {
    User, Admin
}
