package com.trading.commodity.dto;

import java.math.BigDecimal;

public class TradeRequest {
    private Integer userId;
    private Integer commodityId;
    private String tradeType;
    private BigDecimal quantity;
    private BigDecimal tradePrice;

    // Getters and Setters
    public Integer getUserId() { return userId; }
    public void setUserId(Integer userId) { this.userId = userId; }

    public Integer getCommodityId() { return commodityId; }
    public void setCommodityId(Integer commodityId) { this.commodityId = commodityId; }

    public String getTradeType() { return tradeType; }
    public void setTradeType(String tradeType) { this.tradeType = tradeType; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public void setTradePrice(BigDecimal tradePrice) {
        this.tradePrice = tradePrice;
    }
    public BigDecimal getTradePrice(){ return tradePrice; }
}
